<?php

namespace App\Imports;

use Illuminate\Support\Facades\Log;


use App\Models\LegalInstrument;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class LegalInstrumentImport implements ToModel, WithHeadingRow
{
    protected $countryId;
    protected $stateId;

    public function __construct($stateId = null, $categoryId = null)
    {
        $this->stateId = $stateId;
        $this->categoryId = $categoryId;
    }

    public function model(array $row)
    {
        //Log::info('Import Row Data:', $row);
        
        // Skip empty rows
        if (empty($row['title'])) {
            return null;
        }

        return new LegalInstrument([
            'title' => $row['title'] ?? null,
            'year' => $row['year'] ?? null,
            'document_number' => $row['document_number'] ?? null,
            'headnote' => $row['headnote'] ?? null,
            'caselaw_category_id' => $this->categoryId,
            'state_id' => $this->stateId,
        ]);
    }
}