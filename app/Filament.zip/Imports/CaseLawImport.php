<?php

namespace App\Imports;

use App\Models\Caselaw;
use App\Models\CaseLawCategory;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class CaseLawImport implements ToModel, WithHeadingRow
{
    protected $stateId;
    protected $categoryId;
    protected $orderTypeId;

    public function __construct($stateId, $categoryId, $orderTypeId)
    {
        $this->stateId = $stateId;
        $this->categoryId = $categoryId;
        $this->orderTypeId = $orderTypeId;
    }

    /**
     * Make sure Excel starts reading from the first row (A1)
     */
    public function headingRow(): int
    {
        return 1;
    }

    public function model(array $row)
    {
        // Debug: you can uncomment this temporarily if you still have issues
        \Log::info('Row read:', $row);

        if (empty($row)) {
            \Log::warning('Empty row encountered');
            return null;
        }

        $parties = $row['parties'] ?? $row['Parties'] ?? null;

        if (empty($parties)) {
            \Log::warning('Skipping row: no parties field', $row);
            return null;
        }

        // Handle both lowercase or capitalized headings
        $parties = $row['parties'] ?? $row['Parties'] ?? null;

        // Skip blank rows or missing parties
        if (empty($parties)) {
            return null;
        }


         $categoryId = $this->categoryId; // value from form if selected

        if (!$categoryId && !empty($row['category'])) {
            // Try to find a matching category by name (case-insensitive)
            $categoryName = trim($row['category']);
            $category = CaseLawCategory::whereRaw('LOWER(name) = ?', [Str::lower($categoryName)])->first();

            // If category doesn't exist, optionally create it
            if (!$category) {
                $category = CaseLawCategory::create(['name' => ucfirst($categoryName)]);
            }

            $categoryId = $category->id;
        }



        return new Caselaw([
            'parties' => trim($parties),
            'slug' => Str::slug($parties . '-' . ($row['year'] ?? '').$row['document_number']),
            'year' => $row['year'] ?? null,
            'case_no' => $row['case_no'] ?? null,
            'document_number' => $row['document_number'] ?? null,
            'date_of_judgement' => $row['date_of_judgement'] ?? null,
            'headnote' => $row['headnote'] ?? null,
            'state_id' => $this->stateId,
            'caselaw_category_id' => $categoryId,
            'type_of_order_id' => $this->orderTypeId,
        ]);
    }
}
