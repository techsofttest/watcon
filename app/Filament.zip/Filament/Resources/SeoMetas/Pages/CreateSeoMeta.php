<?php

namespace App\Filament\Resources\SeoMetas\Pages;

use App\Filament\Resources\SeoMetas\SeoMetaResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSeoMeta extends CreateRecord
{
    protected static string $resource = SeoMetaResource::class;
}
