<?php

namespace App\Filament\Resources\WorkPackages\Pages;

use App\Filament\Resources\WorkPackages\WorkPackageResource;
use Filament\Resources\Pages\CreateRecord;

class CreateWorkPackage extends CreateRecord
{
    protected static string $resource = WorkPackageResource::class;
}
